from typing import Dict

from models.prediction import PredictionResult


PLACEHOLDER_EVIDENCE_STANDARD_MET = False
PLACEHOLDER_EVIDENCE_REASON = "Phase 0 placeholder"

PLACEHOLDER_RISK_FLAGS = "none"
PLACEHOLDER_ISSUE_TYPE = "unknown"
PLACEHOLDER_OBJECT_PART = "unknown"

PLACEHOLDER_CLAIM_STATUS = "not_enough_information"
PLACEHOLDER_CLAIM_STATUS_REASON = "Phase 0 placeholder"

PLACEHOLDER_SUPPORTING_IMAGES = "none"
PLACEHOLDER_VALID_IMAGE = True

PLACEHOLDER_SEVERITY = "unknown"


class PlaceholderPredictor:
    """
    Temporary predictor used in Phase 0.

    Later this can be replaced by:
    - ClaimParser
    - ImageAnalyzer
    - EvidenceEngine
    - RiskEngine
    - DecisionEngine
    """

    def predict(self, row) -> Dict:
        prediction = PredictionResult(
            evidence_standard_met=PLACEHOLDER_EVIDENCE_STANDARD_MET,
            evidence_standard_met_reason=PLACEHOLDER_EVIDENCE_REASON,
            risk_flags=PLACEHOLDER_RISK_FLAGS,
            issue_type=PLACEHOLDER_ISSUE_TYPE,
            object_part=PLACEHOLDER_OBJECT_PART,
            claim_status=PLACEHOLDER_CLAIM_STATUS,
            claim_status_justification=PLACEHOLDER_CLAIM_STATUS_REASON,
            supporting_image_ids=PLACEHOLDER_SUPPORTING_IMAGES,
            valid_image=PLACEHOLDER_VALID_IMAGE,
            severity=PLACEHOLDER_SEVERITY,
        )

        return prediction.to_dict()